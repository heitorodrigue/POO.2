﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq;
using System;
using System.Windows;
using UVVFintech.Services;
using UVVFintech.Models;

namespace UVVFintech.Views
{
    public partial class TransacoesView : Window
    {
        private readonly TransacaoService _transacaoService;
        private readonly ContaService _contaService;

        public TransacoesView(TransacaoService transacaoService, ContaService contaService)
        {
            InitializeComponent();
            _transacaoService = transacaoService;
            _contaService = contaService;
            CarregarContas();
        }

        private async void CarregarContas()
        {
            cmbContas.ItemsSource = await _contaService.GetAllAsync();
        }

        private async void BtnCarregar_Click(object sender, RoutedEventArgs e)
        {
            if (cmbContas.SelectedValue is int contaId)
            {
                gridTransacoes.ItemsSource = await _transacaoService.GetByContaAsync(contaId);
            }
        }
    }
}
