﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVVFintech.Controllers;
using UVVFintech.Data;
using System;
using System.Windows;
using UVVFintech.Models;
using UVVFintech.Services;

namespace UVVFintech.Views
{
    public partial class ClientesView : Window
    {
        private readonly ClienteService _service;
        private Cliente _selecionado;

        public ClientesView(ClienteService service)
        {
            InitializeComponent();
            _service = service;
            CarregarAsync();
        }

        private async void CarregarAsync()
        {
            gridClientes.ItemsSource = await _service.GetAllAsync();
        }

        private async void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_selecionado == null)
                {
                    var novo = new Cliente
                    {
                        Nome = txtNome.Text,
                        Email = txtEmail.Text,
                        Telefone = txtTelefone.Text
                    };
                    await _service.AddAsync(novo);
                }
                else
                {
                    _selecionado.AtualizarContato(txtNome.Text, txtEmail.Text, txtTelefone.Text);
                    await _service.UpdateAsync(_selecionado);
                    _selecionado = null;
                }

                CarregarAsync();
                LimparForm();
            }
            catch (DomainException dx)
            {
                MessageBox.Show(dx.Message, "Erro de negócio", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void BtnExcluir_Click(object sender, RoutedEventArgs e)
        {
            if (gridClientes.SelectedItem is Cliente c)
            {
                await _service.DeleteAsync(c.ClienteId);
                CarregarAsync();
            }
        }

        private void LimparForm()
        {
            txtNome.Clear();
            txtEmail.Clear();
            txtTelefone.Clear();
            _selecionado = null;
        }

        private void BtnFechar_Click(object sender, RoutedEventArgs e) => this.Close();

        private void gridClientes_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (gridClientes.SelectedItem is Cliente c)
            {
                _selecionado = c;
                txtNome.Text = c.Nome;
                txtEmail.Text = c.Email;
                txtTelefone.Text = c.Telefone;
            }
        }
    }
}
