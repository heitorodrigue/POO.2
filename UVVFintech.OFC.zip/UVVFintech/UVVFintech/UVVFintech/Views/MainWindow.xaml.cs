﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using UVVFintech.Data;
using UVVFintech.Services;

namespace UVVFintech.Views
{
    public partial class MainWindow : Window
    {
        private readonly FintechDbContext _db;
        private readonly ClienteService _clienteService;
        private readonly ContaService _contaService;
        private readonly TransacaoService _transacaoService;

        public MainWindow()
        {
            InitializeComponent();

            try
            {
                // Use apenas 1 DbContext (o mesmo que o App usa)
                _db = App.Db;

                _clienteService = new ClienteService(_db);
                _contaService = new ContaService(_db);
                _transacaoService = new TransacaoService(_db);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show($"Erro ao iniciar: {ex.Message}");
                Application.Current.Shutdown();
            }
        }

        private void BtnClientes_Click(object sender, RoutedEventArgs e)
        {
            var win = new ClientesView(_clienteService);
            win.ShowDialog();
        }

        private void BtnContas_Click(object sender, RoutedEventArgs e)
        {
            var win = new ContasView(_contaService, _clienteService);
            win.ShowDialog();
        }

        private void BtnTransacoes_Click(object sender, RoutedEventArgs e)
        {
            var win = new TransacoesView(_transacaoService, _contaService);
            win.ShowDialog();
        }
    }
}
