﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System;
using System.Windows;
using UVVFintech.Models;
using UVVFintech.Services;

namespace UVVFintech.Views
{
    public partial class ContasView : Window
    {
        private readonly ContaService _contaService;
        private readonly ClienteService _clienteService;

        public ContasView(ContaService contaService, ClienteService clienteService)
        {
            InitializeComponent();
            _contaService = contaService;
            _clienteService = clienteService;
            CarregarAsync();
        }

        private async void CarregarAsync()
        {
            cmbClientes.ItemsSource = await _clienteService.GetAllAsync();
            lstContas.ItemsSource = await _contaService.GetAllAsync();
        }

        private async void BtnCriar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbClientes.SelectedItem is not Cliente cliente)
                {
                    MessageBox.Show("Selecione um cliente.");
                    return;
                }

                if (!decimal.TryParse(txtSaldo.Text, out var saldo))
                {
                    MessageBox.Show("Saldo inválido.");
                    return;
                }

                var tipo = (cmbTipo.SelectedItem as ComboBoxItem)?.Content?.ToString();

                Conta nova = null;

                if (tipo == "Conta Corrente")
                {
                    decimal.TryParse(txtLimite.Text, out var limite);
                    nova = new ContaCorrente(txtNumero.Text, saldo, limite) { ClienteId = cliente.ClienteId };
                }
                else // poupanca
                {
                    nova = new ContaPoupanca(txtNumero.Text, saldo) { ClienteId = cliente.ClienteId };
                }

                await _contaService.AddAsync(nova);
                MessageBox.Show("Conta criada!");
                CarregarAsync();
            }
            catch (DomainException dx)
            {
                MessageBox.Show(dx.Message, "Erro de negócio");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro");
            }
        }

        private async void BtnAplicarRendimento_Click(object sender, RoutedEventArgs e)
        {
            if (lstContas.SelectedItem is Conta c && c is ContaPoupanca poup)
            {
                poup.AplicarRendimentoMensal();
                await _contaService.UpdateAsync(poup);
                CarregarAsync();
                MessageBox.Show("Rendimento aplicado.");
            }
            else
            {
                MessageBox.Show("Selecione uma conta poupança.");
            }
        }

        private void BtnFechar_Click(object sender, RoutedEventArgs e) => this.Close();
    }
}
