﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UVVFintech.Models;
using UVVFintech.Services;

namespace UVVFintech.Controllers
{
    public class TransacaoController
    {
        private readonly TransacaoService _transacaoService;

        public TransacaoController(TransacaoService transacaoService)
        {
            _transacaoService = transacaoService;
        }

        public Task<List<Transacao>> ListarAsync()
        {
            return _transacaoService.GetAllAsync();
        }

        public Task<List<Transacao>> BuscarPorContaAsync(int contaId)
        {
            return _transacaoService.GetByContaAsync(contaId);
        }

        public Task RegistrarAsync(Transacao transacao)
        {
            return _transacaoService.AddAsync(transacao);
        }
    }
}
