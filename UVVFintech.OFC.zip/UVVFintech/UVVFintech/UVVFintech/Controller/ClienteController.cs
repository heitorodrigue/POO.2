﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UVVFintech.Models;
using UVVFintech.Services;

namespace UVVFintech.Controllers
{
    public class ClienteController
    {
        private readonly ClienteService _clienteService;

        public ClienteController(ClienteService clienteService)
        {
            _clienteService = clienteService;
        }

        public Task<List<Cliente>> ListarTodosAsync()
        {
            return _clienteService.GetAllAsync();
        }

        public Task<Cliente> BuscarPorIdAsync(int id)
        {
            return _clienteService.GetByIdAsync(id);
        }

        public Task AdicionarAsync(Cliente cliente)
        {
            return _clienteService.AddAsync(cliente);
        }

        public Task AtualizarAsync(Cliente cliente)
        {
            return _clienteService.UpdateAsync(cliente);
        }

        public Task RemoverAsync(int id)
        {
            return _clienteService.DeleteAsync(id);
        }
    }
}
