﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UVVFintech.Models;
using UVVFintech.Services;

namespace UVVFintech.Controllers
{
    public class ContaController
    {
        private readonly ContaService _contaService;

        public ContaController(ContaService contaService)
        {
            _contaService = contaService;
        }

        public Task<List<Conta>> ListarAsync()
        {
            return _contaService.GetAllAsync();
        }

        public Task<Conta> BuscarPorIdAsync(int id)
        {
            return _contaService.GetByIdAsync(id);
        }

        public Task CriarAsync(Conta conta)
        {
            return _contaService.AddAsync(conta);
        }

        public Task AtualizarAsync(Conta conta)
        {
            return _contaService.UpdateAsync(conta);
        }

        public Task RemoverAsync(int id)
        {
            return _contaService.DeleteAsync(id);
        }
    }
}
