﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace UVVFintech.Data
{
    public class DesignTimeFintechDbContextFactory : IDesignTimeDbContextFactory<FintechDbContext>
    {
        public FintechDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<FintechDbContext>();

            optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=UVVFintech;Trusted_Connection=True;");

            return new FintechDbContext(optionsBuilder.Options);
        }
    }
}
