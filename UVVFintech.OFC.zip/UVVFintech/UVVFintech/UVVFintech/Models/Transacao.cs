﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UVVFintech.Models
{
    public class Transacao
    {
        public int TransacaoId { get; set; }

        [Required]
        public TipoTransacao Tipo { get; set; }

        [Required]
        public decimal Valor { get; set; }

        [Required]
        public DateTime Data { get; set; }

        public int ContaId { get; set; }
        public Conta Conta { get; set; }

        public int? ContaRelacionadaId { get; set; }

        public Transacao() { }

        public Transacao(TipoTransacao tipo, decimal valor, DateTime data, Conta conta)
        {
            if (conta == null)
                throw new DomainException("Transação precisa de conta.");

            Tipo = tipo;
            Valor = valor;
            Data = data;
            Conta = conta;
            ContaId = conta.ContaId;
        }
    }
}
