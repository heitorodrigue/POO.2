﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace UVVFintech.Models
{
    public class Cliente
    {
        public int ClienteId { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 3)]
        public string Nome { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Phone]
        public string Telefone { get; set; }

        public DateTime DataCadastro { get; private set; } = DateTime.UtcNow;

        public ICollection<Conta> Contas { get; set; } = new List<Conta>();

        public void AtualizarContato(string nome, string email, string telefone = null)
        {
            if (string.IsNullOrWhiteSpace(nome) || nome.Length < 3)
                throw new DomainException("Nome deve ter pelo menos 3 caracteres.");

            if (!new EmailAddressAttribute().IsValid(email))
                throw new DomainException("Email inválido.");

            Nome = nome.Trim();
            Email = email.Trim();
            Telefone = telefone?.Trim();
        }
    }
}
