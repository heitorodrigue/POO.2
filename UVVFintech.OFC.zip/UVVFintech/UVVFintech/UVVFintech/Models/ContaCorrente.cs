﻿using System;

namespace UVVFintech.Models
{
    public class ContaCorrente : Conta
    {
        public decimal Limite { get; private set; } = 1000m; // limite padrão

        public ContaCorrente() { }

        public ContaCorrente(string numero, decimal saldoInicial = 0m, decimal limite = 1000m)
            : base(numero, saldoInicial)
        {
            if (limite < 0)
                throw new DomainException("Limite não pode ser negativo.");

            Limite = limite;
        }

        public override void Sacar(decimal valor)
        {
            if (valor <= 0)
                throw new DomainException("Valor inválido para saque.");

            if (Saldo + Limite < valor)
                throw new DomainException("Saldo insuficiente considerando o limite.");

            Saldo -= valor;

            Transacoes.Add(new Transacao(TipoTransacao.Saque, -valor, DateTime.UtcNow, this));
        }
    }
}
