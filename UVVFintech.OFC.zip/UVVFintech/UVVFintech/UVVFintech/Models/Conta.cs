﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;

namespace UVVFintech.Models
{
    public abstract class Conta
    {
        public int ContaId { get; set; }

        [Required]
        [StringLength(30)]
        public string Numero { get; private set; }

        public decimal Saldo { get; protected set; } = 0m;

        public int ClienteId { get; set; }
        public Cliente Cliente { get; set; }

        public ICollection<Transacao> Transacoes { get; set; } = new List<Transacao>();

        protected Conta() { }

        protected Conta(string numero, decimal saldoInicial = 0m)
        {
            if (!ValidarNumeroConta(numero))
                throw new DomainException("Número da conta inválido.");

            Numero = numero;

            if (saldoInicial < 0)
                throw new DomainException("Saldo inicial não pode ser negativo.");

            Saldo = saldoInicial;

            if (saldoInicial > 0)
                Transacoes.Add(new Transacao(TipoTransacao.Deposito, saldoInicial, DateTime.UtcNow, this));
        }

        public static bool ValidarNumeroConta(string numero)
        {
            var regex = new Regex(@"^[A-Za-z0-9\-]{4,30}$");
            return regex.IsMatch(numero);
        }

        // Métodos básicos que podem ser sobrescritos nas contas derivadas
        public virtual void Depositar(decimal valor)
        {
            if (valor <= 0)
                throw new DomainException("Depósito deve ser maior que zero.");

            Saldo += valor;
            Transacoes.Add(new Transacao(TipoTransacao.Deposito, valor, DateTime.UtcNow, this));
        }

        public virtual void Sacar(decimal valor)
        {
            if (valor <= 0)
                throw new DomainException("Saque deve ser maior que zero.");

            if (Saldo < valor)
                throw new DomainException("Saldo insuficiente.");

            Saldo -= valor;
            Transacoes.Add(new Transacao(TipoTransacao.Saque, -valor, DateTime.UtcNow, this));
        }

        public void TransferirPara(Conta destino, decimal valor)
        {
            if (destino == null)
                throw new DomainException("Conta destino inválida.");

            if (destino.ContaId == this.ContaId)
                throw new DomainException("Não é possível transferir para a mesma conta.");

            Sacar(valor);
            destino.Depositar(valor);

            Transacoes.Add(new Transacao(TipoTransacao.TransferenciaEnvio, -valor, DateTime.UtcNow, this)
            {
                ContaRelacionadaId = destino.ContaId
            });

            destino.Transacoes.Add(new Transacao(TipoTransacao.TransferenciaRecebimento, valor, DateTime.UtcNow, destino)
            {
                ContaRelacionadaId = this.ContaId
            });
        }
    }
}
