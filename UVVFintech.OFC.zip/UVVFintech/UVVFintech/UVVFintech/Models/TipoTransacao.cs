﻿namespace UVVFintech.Models
{
    public enum TipoTransacao
    {
        Deposito,
        Saque,
        TransferenciaEnvio,
        TransferenciaRecebimento
    }
}
