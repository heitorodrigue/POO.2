﻿using System;

namespace UVVFintech.Models
{
    public class ContaPoupanca : Conta
    {
        public decimal TaxaRendimento { get; private set; } = 0.005m; // 0.5% ao mês

        public ContaPoupanca() { }

        public ContaPoupanca(string numero, decimal saldoInicial = 0m)
            : base(numero, saldoInicial) { }

        public void AplicarRendimentoMensal()
        {
            if (Saldo <= 0) return;

            var rendimento = Saldo * TaxaRendimento;
            Saldo += rendimento;

            Transacoes.Add(new Transacao(
                TipoTransacao.Deposito,
                rendimento,
                DateTime.UtcNow,
                this
            ));
        }
    }
}
