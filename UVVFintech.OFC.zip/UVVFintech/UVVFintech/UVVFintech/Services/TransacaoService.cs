﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UVVFintech.Data;
using UVVFintech.Models;

namespace UVVFintech.Services
{
    public class TransacaoService
    {
        private readonly FintechDbContext _context;

        public TransacaoService(FintechDbContext context)
        {
            _context = context;
        }

        public async Task<List<Transacao>> GetAllAsync()
        {
            return await _context.Transacoes
                .Include(t => t.Conta)
                .ToListAsync();
        }

        public async Task<List<Transacao>> GetByContaAsync(int contaId)
        {
            return await _context.Transacoes
                .Where(t => t.ContaId == contaId)
                .OrderByDescending(t => t.Data)
                .ToListAsync();
        }

        public async Task AddAsync(Transacao transacao)
        {
            _context.Transacoes.Add(transacao);
            await _context.SaveChangesAsync();
        }
    }
}
