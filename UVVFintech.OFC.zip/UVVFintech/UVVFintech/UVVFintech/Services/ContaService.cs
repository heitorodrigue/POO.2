﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using UVVFintech.Data;
using UVVFintech.Models;

namespace UVVFintech.Services
{
    public class ContaService
    {
        private readonly FintechDbContext _context;

        public ContaService(FintechDbContext context)
        {
            _context = context;
        }

        public async Task<List<Conta>> GetAllAsync()
        {
            return await _context.Contas
                .Include(c => c.Cliente)
                .Include(c => c.Transacoes)
                .ToListAsync();
        }

        public async Task<Conta> GetByIdAsync(int id)
        {
            return await _context.Contas
                .Include(c => c.Cliente)
                .Include(c => c.Transacoes)
                .FirstOrDefaultAsync(c => c.ContaId == id);
        }

        public async Task AddAsync(Conta conta)
        {
            _context.Contas.Add(conta);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Conta conta)
        {
            _context.Contas.Update(conta);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var conta = await _context.Contas.FindAsync(id);
            if (conta != null)
            {
                _context.Contas.Remove(conta);
                await _context.SaveChangesAsync();
            }
        }
    }
}
