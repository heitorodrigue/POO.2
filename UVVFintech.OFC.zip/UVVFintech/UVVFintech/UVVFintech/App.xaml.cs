﻿using Microsoft.EntityFrameworkCore;
using System.Windows;
using UVVFintech.Data;
using UVVFintech.Views;

namespace UVVFintech
{
    public partial class App : Application
    {
        public static FintechDbContext Db { get; private set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var options = new DbContextOptionsBuilder<FintechDbContext>()
                .UseSqlServer("Server=DESKTOP-7UF3IIS\\SQLEXPRESS;Database=UVVFintechDB;Trusted_Connection=True;TrustServerCertificate=True;")
                .Options;

            Db = new FintechDbContext(options);

            new MainWindow().Show();
        }
    }
}
